package com.bugly.upgrade.demo;

import android.app.Activity;
import android.os.Bundle;

/**
 *
 * @author wenjiewu
 */
public class OtherActivity extends Activity{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_other);
    }
}
